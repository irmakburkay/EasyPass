package com.irmakburkay.easypass;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.irmakburkay.easypass.R;

import java.util.ArrayList;
import java.util.List;


public class PassEntryFragment extends Fragment {

    private View view;
    //    private ListView passList;
//    private PassEntryViewAdapter adapter;
    private List<Password> passwords = new ArrayList<>();

    //    ---------------------------------
    private RecyclerView rv;
    private PassEntryRecyclerViewAdapter rvAdapter;


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        passwords = EasyPassMainActivity.passwordDao.loadAllPasswords();
//        adapter = new PassEntryViewAdapter(getContext(), passwords);
        rvAdapter = new PassEntryRecyclerViewAdapter(passwords);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_pass_entry, container, false);

        rv = view.findViewById(R.id.list);
        rv.setHasFixedSize(true);
        rv.setAdapter(rvAdapter);
        rv.addItemDecoration(new DividerItemDecoration(getContext(), LinearLayoutManager.VERTICAL));

//        passList = view.findViewById(R.id.list);
//
//        passList.setAdapter(adapter);

//        registerEventHandlers();

        return view;
    }

//    private void registerEventHandlers() {
//        passList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//            @Override
//            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
//                Password password = (Password) passList.getItemAtPosition(i);
//                ClipboardManager clipboard = (ClipboardManager) getContext().getSystemService(Context.CLIPBOARD_SERVICE);
//                ClipData clip = ClipData.newPlainText("Şifre", password.getPass());
//                clipboard.setPrimaryClip(clip);
//                Toast.makeText(getContext(), "Kopyalandı " + password.getPass(), Toast.LENGTH_SHORT).show();
//            }
//        });
//
//        passList.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
//            @Override
//            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
//                Password password = (Password) passList.getItemAtPosition(i);
//                AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
//                builder.setTitle("Emin misiniz?");
//                builder.setMessage("Şifreyi silmek istediğinizden emin misiniz?");
//                builder.setIcon(R.drawable.ic_warning);
//
//                DialogInterface.OnClickListener listener = new DialogInterface.OnClickListener() {
//
//                    @Override
//                    public void onClick(DialogInterface dialogInterface, int i) {
//                        if (i == DialogInterface.BUTTON_POSITIVE) {
//                            EasyPassMainActivity.passwordDao.deletePassword(password);
//                            refreshList();
//                            Snackbar snackbar = Snackbar.make(passList, password.getName() + " silindi", Snackbar.LENGTH_LONG);
//                            snackbar.setAction("Geri Al", new View.OnClickListener() {
//                                @Override
//                                public void onClick(View view) {
//                                    EasyPassMainActivity.passwordDao.insertPassword(password);
//                                    refreshList();
//                                }
//                            });
//                            snackbar.show();
//                        } else {
//
//                        }
//                    }
//                };
//
//                builder.setPositiveButton("Evet", listener);
//                builder.setNegativeButton("Hayır", listener);
//
//                AlertDialog alertDialog = builder.create();
//                alertDialog.show();
//
//                return true;
//            }
//        });
//
//    }
//
//    private void refreshList() {
//        passwords = EasyPassMainActivity.passwordDao.loadAllPasswords();
//        adapter = new PassEntryViewAdapter(getContext(), passwords);
//        passList.setAdapter(adapter);
//    }

}